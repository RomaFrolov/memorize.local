Svidotstvo Ukrainian Institute of Intellectual Property N 108015
Шрифт RuteniaDecor © VasylChebanyk поширюється на умовах ліцензії Creative Commons Attribution-Share Alike 4.0. Copyright (c) 2016 by Vasyl Chebanyk.  All rights reserved. 
(CC BY-SA 4.0)

Коротко: ви можете вільно поширювати цей твір, змінювати і використовувати його в будь-яких цілях за умови 
вказівки оригінального авторства і збереження цієї (чи сумісної) ліцензії в похідних творах.

Шрифт знаходиться у процесі доробки та на даний час містить українськи літери, цифри та базову пунктуацію.

Якщо Вам потрібні інші умови ліцензування, зверніться з запитом на адресу info@abetkarutenia.com.ua